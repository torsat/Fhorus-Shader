#version 120
#define DIM_END
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lit_vsh.glsl"

varying vec4 vColor;

void main() {
  todSetup();
  vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
  litSetup(viewPos, normalize(gl_NormalMatrix * gl_Normal), gl_MultiTexCoord1.xy, 0.0);
  vTex.xy = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  vColor = gl_Color;
  gl_Position = ftransform();   // exactly the vanilla position, so the enchant glint overlay passes the depth test
}
