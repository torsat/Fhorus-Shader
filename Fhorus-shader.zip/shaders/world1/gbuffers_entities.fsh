#version 120
#define DIM_END
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lit_fsh.glsl"

uniform sampler2D texture;
uniform vec4 entityColor;   // hurt flash, creeper charge, ...
varying vec4 vColor;

/* DRAWBUFFERS:1 */
void main() {
  vec4 tex = texture2D(texture, vTex.xy) * vColor;
  if (tex.a < 0.1) discard;
  tex.rgb = mix(tex.rgb, entityColor.rgb, entityColor.a);
  gl_FragData[0] = vec4(shadeLit(toLinear(tex.rgb), 1.0), tex.a);
}
