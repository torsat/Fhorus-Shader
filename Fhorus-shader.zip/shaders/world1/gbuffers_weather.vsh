#version 120
#define DIM_END
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/tod.glsl"

varying vec2 uv;
varying vec4 vColor;
varying vec3 vSun;

void main() {
  todSetup();
  uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  vColor = gl_Color;
  vSun = gLightCol * 0.3;
  gl_Position = ftransform();
}
