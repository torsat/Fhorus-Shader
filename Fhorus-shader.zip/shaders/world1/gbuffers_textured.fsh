#version 120
#define DIM_END
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lit_fsh.glsl"

uniform sampler2D texture;
varying vec4 vColor;

/* DRAWBUFFERS:1 */
void main() {
  vec4 tex = texture2D(texture, vTex.xy) * vColor;
  if (tex.a < 0.1) discard;
  vec3 albedo = toLinear(tex.rgb);
  // particles are small and often glowing: never let them go fully dark
  gl_FragData[0] = vec4(max(shadeLit(albedo, 1.0), albedo * 0.35), tex.a);
}
