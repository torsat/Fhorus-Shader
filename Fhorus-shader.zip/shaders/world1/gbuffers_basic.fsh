#version 120
#define DIM_END
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lit_fsh.glsl"

varying vec4 vColor;

/* DRAWBUFFERS:1 */
void main() {
  if (vColor.a < 0.05) discard;
  gl_FragData[0] = vec4(shadeLit(toLinear(vColor.rgb), 1.0), vColor.a);
}
