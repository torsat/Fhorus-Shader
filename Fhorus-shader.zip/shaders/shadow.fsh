#version 120
varying vec2 uv;
uniform sampler2D tex;

void main() {
  vec4 c = texture2D(tex, uv);
  if (c.a < 0.1) discard;
  gl_FragData[0] = c;
}
