#version 120
varying vec2 uv;
varying vec4 vColor;

void main() {
  uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  vColor = gl_Color;
  gl_Position = ftransform();
}
