#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D texture;
uniform sampler2D gaux1;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 uv;
varying float vShade;
varying vec3 vSun;

/* DRAWBUFFERS:1 */
void main() {
  vec4 t = texture2D(texture, uv);
  if (t.a < 0.05) discard;
  vec3 amb = texture2D(gaux1, vec2(16.5, 0.5) / vec2(viewWidth, viewHeight)).rgb;
  amb = mix(vec3(luma(amb)), amb, 0.3) * 1.8;     // keep clouds mostly neutral
  gl_FragData[0] = vec4((amb * vShade + vSun) * toLinear(t.rgb), t.a * 0.85);
}
