#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D texture;
uniform float rainStrength;
varying vec2 uv;
varying vec4 vColor;
varying float vIsSun;
varying float vElev;

/* DRAWBUFFERS:1 */
void main() {
  vec4 t = texture2D(texture, uv);
#if defined DIM_OVERWORLD
  // keep only the bright sprite pixels so the square background never shows
  float m = t.a * smoothstep(0.02, 0.15, max(t.r, max(t.g, t.b)));
  m *= smoothstep(-0.03, 0.10, vElev);   // fade out as the sprite touches the horizon
  m *= 1.0 - rainStrength;                 // sun and moon disappear in rain
  if (m < 0.02) discard;

  // first colour is the moon, second is the sun; the numbers set how bright they are
  vec3 boost = mix(vec3(1.0, 1.05, 1.25) * 2.2, vec3(1.3, 1.05, 0.8) * 6.0, vIsSun);
  gl_FragData[0] = vec4(toLinear(t.rgb * vColor.rgb) * boost, m * vColor.a);
#else
  gl_FragData[0] = vec4(toLinear((t * vColor).rgb) * 0.45, vColor.a);   // End sky box
#endif
}
