// Crumb - every tweakable option lives here so it shows up in the in-game menu.

// ---------- Lighting ----------
#define SUN_INTENSITY 2.3 //[1.0 1.5 2.0 2.3 2.6 3.0 3.5 4.0]
#define AMBIENT_INTENSITY 1.0 //[0.5 0.75 1.0 1.25 1.5 2.0]
#define MOON_INTENSITY 0.3 //[0.0 0.5 1.0 1.5 2.0]
#define MIN_LIGHT 1.0 //[0.0 0.5 1.0 2.0 4.0 8.0]
#define TORCH_AMOUNT 2.0 //[0.0 0.5 0.75 1.0 1.25 1.5 2.0]
#define TORCH_R 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0]
#define TORCH_G 0.52 //[0.2 0.3 0.4 0.52 0.6 0.7 0.8 0.9 1.0]
#define TORCH_B 0.2 //[0.0 0.1 0.2 0.3 0.4 0.5 0.7 1.0]
#define CEL_STEPS 0 //[0 2 3 4 5 6]
#define SHADOW_DARKNESS 0.5 //[0.0 0.25 0.4 0.5 0.6 0.75]   how much darker shadowed areas are in daylight
#define AO_STRENGTH 0.8 //[0.0 0.25 0.5 0.75 0.8 1.0]

// ---------- Shadows ----------
#define SHADOW_QUALITY 1 //[0 1 2]
const int shadowMapResolution = 1024; //[512 768 1024 1536 2048 3072 4096]
const float shadowDistance = 64.0; //[32.0 48.0 64.0 96.0 128.0 160.0]
#define SHADOW_BIAS 1.0 //[0.5 0.75 1.0 1.5 2.0 3.0]
const float sunPathRotation = -30.0; //[0.0 -10.0 -20.0 -30.0 -40.0 -50.0 -60.0]
const bool shadowHardwareFiltering0 = true;

// ---------- Atmosphere ----------
#define SKY_BRIGHTNESS 1.5 //[0.6 0.8 1.0 1.2 1.5]
#define FOG_DENSITY 0.75 //[0.0 0.5 0.75 1.0 1.5 2.0 3.0]
#define NIGHT_EXPOSURE 0.5 //[0.5 1.0 1.5 1.8 2.2 2.6 3.2 4.0]
#define END_SKY 1 //[0 1]

// ---------- World ----------
#define GLOW_STRENGTH 1.5 //[0.0 0.5 1.0 1.5 2.0 3.0]
#define WAVING 1 //[0 1]
#define WAVE_AMOUNT 1.0 //[0.5 1.0 1.5 2.0]
#define WATER_REFLECT 1.0 //[0.0 0.5 1.0 1.5]
#define WATER_ALPHA 0.62 //[0.3 0.4 0.5 0.62 0.75 0.9]
#define SUN_GLINT_BRIGHT 6.0 //[0.0 2.0 4.0 6.0 10.0 15.0 30.0]   sun sparkle on water
#define SUN_GLINT_SHARP 1800.0 //[500.0 700.0 1200.0 1800.0 3000.0]   higher = smaller glint
#define WATER_DEPTH_FADE 0.22 //[0.08 0.12 0.16 0.22 0.3 0.45]   higher = water gets opaque/dark sooner with depth

// ---------- Post ----------
#define TONEMAP 1 //[0 1 2]
#define EXPOSURE 1.0 //[0.5 0.75 0.9 1.0 1.1 1.25 1.5 2.0]
#define SATURATION 1.12 //[0.0 0.6 0.8 1.0 1.12 1.2 1.4]
#define CONTRAST 0.25 //[0.0 0.15 0.25 0.35 0.5]   S-curve, fights the flat look
#define VIGNETTE 0.0 //[0.0 0.15 0.3 0.45]
#define PIXEL_SIZE 1 //[1 2 3 4 6 8]
