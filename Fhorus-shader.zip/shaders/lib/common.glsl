// Crumb - small shared helpers (no uniforms in here)
#if !defined DIM_NETHER && !defined DIM_END
#define DIM_OVERWORLD
#endif

const float PI = 3.14159265;

// cheap sRGB -> linear, close to pow(c, 2.2)
vec3 toLinear(vec3 c) { return c * c * (c * 0.35 + 0.65); }

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

// interleaved gradient noise, 0..1
float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }

// shadow map warp: more texels near the player (xy in shadow clip space)
float shadowWarp(vec2 p) { return length(p) * 0.85 + 0.15; }

// quantise a 0..1 value into n bands (n == 0 means off)
float celBands(float x, float n) {
  return n < 1.5 ? x : floor(x * n + 0.5) / n;
}
