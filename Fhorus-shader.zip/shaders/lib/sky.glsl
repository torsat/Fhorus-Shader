// Crumb - analytic sky, evaluated once into a lookup table by the deferred pass.
// cosY : cosine of the angle between the view ray and the sun
// h    : view ray elevation, 0 (horizon) .. 1 (zenith)
// sunH : sun elevation, -1 .. 1
// ---------------------------------------------------------------------------
// Sky colours. These are the numbers to tweak (red, green, blue; 1.0 = full).
// ---------------------------------------------------------------------------
const vec3 DAY_ZENITH    = vec3(0.010, 0.060, 0.150);// straight up, daytime
const vec3 DAY_HORIZON   = vec3(0.170, 0.300, 0.450);  // at the horizon, daytime
const vec3 NIGHT_ZENITH  = vec3(0.006, 0.007, 0.030);  // deep indigo
const vec3 NIGHT_HORIZON = vec3(0.022, 0.020, 0.065);  // a little lighter, violet
const vec3 DUSK_ZENITH   = vec3(0.090, 0.120, 0.380);
const vec3 DUSK_HORIZON  = vec3(0.500, 0.400, 0.620);
const vec3 DUSK_SUNSIDE  = vec3(1.350, 0.580, 0.240);  // warm glow around the setting sun

// Generic sky: the day colours are passed in so the ambient light can use paler ones.
vec3 skyColor(float cosY, float h, float sunH, float rain, vec3 dayZenith, vec3 dayHorizon) {
  float lum  = smoothstep(-0.20, 0.14, sunH);       // 0 = night, 1 = day
  float xd   = sunH / 0.22;
  float dusk = exp(-xd * xd);                       // 1 when the sun is on the horizon
  float band = pow(1.0 - h, 3.5);                   // wide horizon glow (dusk, night)
  float bandDay = pow(1.0 - h, 6.0);                // tight horizon haze in clear daylight

  vec3 zenith  = mix(dayZenith, DUSK_ZENITH, dusk);
  vec3 horizon = mix(dayHorizon, DUSK_HORIZON, dusk);
  float toward = smoothstep(-0.4, 1.0, cosY);
  horizon = mix(horizon, DUSK_SUNSIDE, dusk * toward * toward);
  vec3 day = mix(zenith, horizon, mix(bandDay, band, dusk));
  day += vec3(1.0, 0.78, 0.52) * pow(max(cosY, 0.0), 90.0) * 0.45 * (1.0 - rain);      // sun halo (bigger number = smaller halo)

  vec3 night = mix(NIGHT_ZENITH, NIGHT_HORIZON, band);
  night += vec3(0.30, 0.30, 0.55) * pow(max(-cosY, 0.0), 120.0) * 0.25 * (1.0 - rain); // moon halo

  vec3 sky = mix(night, day, lum);
  float g = dot(sky, vec3(0.2126, 0.7152, 0.0722));
  sky = mix(sky, vec3(g) * vec3(0.85, 0.90, 1.0) * 0.45, rain * 0.9);   // grey AND darker in rain
  return sky * SKY_BRIGHTNESS;
}

vec3 skyModel(float cosY, float h, float sunH, float rain) {
  return skyColor(cosY, h, sunH, rain, DAY_ZENITH, DAY_HORIZON);
}

// Rough hemisphere average of the sky, used as ambient light. It uses its own, paler
// daytime colours so the world stays bright even though the visible sky is deep blue.
vec3 skyAmbient(float sunH, float rain) {
  vec3 pz = vec3(0.10, 0.30, 0.85);
  vec3 ph = vec3(0.62, 0.80, 1.05);
  vec3 a = skyColor(0.0, 1.0, sunH, rain, pz, ph) * 0.55 + skyColor(0.0, 0.3, sunH, rain, pz, ph) * 0.45;
  a = mix(vec3(dot(a, vec3(0.2126, 0.7152, 0.0722))), a, 0.65);   // shadows should not be pure blue
  return a * AMBIENT_INTENSITY;
}

// Table layout inside the (never cleared) gaux1 / colortex4 buffer:
//   x 0..15, y 0..15   : lightmap, x = block light, y = sky light
//   x 16,    y 0       : ambient sky colour
//   x 32..287, y 0..63 : sky table, 256 (angle to sun, dense at both the sun and the moon) x 64 (elevation)
vec3 sampleSky(sampler2D lut, vec3 dir, vec3 sunDir, vec2 texel) {
  float c = clamp(dot(dir, sunDir), -1.0, 1.0);
  float a = sqrt(sqrt(1.0 - abs(c)));
  float u = 0.5 + 0.5 * sign(c) * (1.0 - a);
  float v = sqrt(clamp(dir.y, 0.0, 1.0));
  vec2 px = vec2(clamp(u * 256.0, 0.5, 255.5) + 32.0, clamp(v * 64.0, 0.5, 63.5));
  return texture2D(lut, px * texel).rgb;
}
