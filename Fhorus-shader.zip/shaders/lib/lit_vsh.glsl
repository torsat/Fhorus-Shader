// Crumb - shared vertex-side lighting for everything that is lit by the world.
// Include after settings/common. Call todSetup() and litSetup() from main().
#include "/lib/tod.glsl"
#if defined DIM_OVERWORLD
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
#endif

varying vec4 vTex;    // xy = texture coords, zw = block/sky light (0..1)
varying vec4 vLight;  // rgb = direct light colour (sky-masked), a = N.L
varying vec4 vShadow; // xyz = shadow clip position, w = shadow fade (0 = no shadow data)
varying vec3 vHemi;   // sky/ground ambient tint

void litSetup(vec3 viewPos, vec3 nView, vec2 lmRaw, float foliage) {
  vec2 lm = clamp(lmRaw / 240.0, 0.0, 1.0);
  vTex.zw = lm;

  float ndl = clamp(dot(nView, gLightDirV), 0.0, 1.0);
  ndl = mix(ndl, 0.65, foliage * 0.7);              // leaves/grass have meaningless normals

#if defined DIM_OVERWORLD
  float skyMask = smoothstep(0.30, 0.85, lm.y);
#else
  float skyMask = 1.0;
#endif
  vLight = vec4(gLightCol * skyMask, ndl);

  vec3 nW = mat3(gbufferModelViewInverse) * nView;
#if defined DIM_OVERWORLD
  vec3 hemi = mix(vec3(0.82, 0.78, 0.78), vec3(0.92, 1.0, 1.1), nW.y * 0.5 + 0.5);
  vHemi = mix(vec3(1.0), hemi, lm.y);
#else
  vHemi = vec3(1.0);
#endif

  vShadow = vec4(0.0);
#if defined DIM_OVERWORLD
  if (SHADOW_QUALITY > 0 && ndl > 0.001 && dot(vLight.rgb, vec3(1.0)) > 0.0005) {
    float dist = length(viewPos);
    float fade = 1.0 - smoothstep(shadowDistance * 0.8, shadowDistance * 0.98, dist);
    if (fade > 0.0) {
      vec3 wp = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
      wp += nW * (0.04 + 0.12 * (1.0 - ndl)) * SHADOW_BIAS;       // normal offset
      vec3 sp = mat3(shadowModelView) * wp + shadowModelView[3].xyz;
      sp = vec3(shadowProjection[0].x, shadowProjection[1].y, shadowProjection[2].z) * sp + shadowProjection[3].xyz;
      vShadow = vec4(sp, fade);
    }
  }
#endif
}
