// Crumb - time-of-day values, computed per vertex (cheap) and handed to fragments as varyings.
uniform vec3 sunPosition;
uniform vec3 shadowLightPosition;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform float rainStrength;

float gSunH;      // sun elevation, -1..1
vec3  gSunDirW;   // sun direction, world space
vec3  gLightDirV; // direction of the active direct light, view space
vec3  gLightCol;  // colour of the active direct light (sun by day, moon by night)

vec3 directLight(float sunH, float lightH, float rain) {
  // lightH is the elevation of whichever body currently casts shadows, so the
  // intensity is already zero at the moment the shadow map flips sun -> moon
  float amt = smoothstep(0.0, 0.14, lightH);
  vec3 sunC = mix(vec3(1.10, 0.52, 0.22), vec3(1.0, 0.93, 0.82), smoothstep(0.02, 0.5, lightH)) * SUN_INTENSITY;
  vec3 moonC = vec3(0.30, 0.40, 0.70) * 0.22 * MOON_INTENSITY;
  return (sunH > 0.0 ? sunC : moonC) * amt * (1.0 - rain * 0.98);   // rain almost completely switches the sun/moon off
}

void todSetup() {
  gSunDirW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
  gSunH = gSunDirW.y;
#if defined DIM_OVERWORLD
  gLightDirV = normalize(shadowLightPosition);
  float lightH = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition).y;
  gLightCol = directLight(gSunH, lightH, rainStrength);
#elif defined DIM_END
  gLightDirV = normalize(mat3(gbufferModelView) * vec3(0.35, 1.0, 0.25));
  gLightCol = vec3(0.50, 0.42, 0.75) * 0.55;
#else
  gLightDirV = vec3(0.0, 1.0, 0.0);
  gLightCol = vec3(0.0);
#endif
}
