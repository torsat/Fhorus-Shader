// Crumb - shared fragment-side lighting.
// Include after settings/common. Needs `uniform sampler2D texture` declared by the program.
varying vec4 vTex;
varying vec4 vLight;
varying vec4 vShadow;
varying vec3 vHemi;

uniform sampler2D gaux1;
uniform float viewWidth;
uniform float viewHeight;
#if defined DIM_OVERWORLD
uniform sampler2DShadow shadow;
#else
uniform vec3 fogColor;
#endif

vec3 lightmapColor(vec2 lm) {
#if defined DIM_OVERWORLD
  vec2 px = (lm * 15.0 + 0.5) / vec2(viewWidth, viewHeight);
  return texture2D(gaux1, px).rgb;
#else
  float t = lm.x;
  float torch = t * t * t * t * 1.6 + t * t * 0.35 + t * 0.05;
  vec3 base;
  #if defined DIM_NETHER
  vec3 f = fogColor / max(max(fogColor.r, fogColor.g), max(fogColor.b, 0.05));
  base = f * 0.06 + 0.012;
  #else
  base = vec3(0.20, 0.15, 0.32) * 0.45;
  #endif
  return base * AMBIENT_INTENSITY + vec3(TORCH_R, TORCH_G, TORCH_B) * TORCH_AMOUNT * torch + 0.004 * MIN_LIGHT;
#endif
}

float shadowLookup() {
#if defined DIM_OVERWORLD
  if (SHADOW_QUALITY == 0 || vShadow.w <= 0.0) return 1.0;
  float warp = shadowWarp(vShadow.xy);
  vec2 uv = vShadow.xy / warp;
  float edge = 1.0 - 2.0 / float(shadowMapResolution);
  if (abs(uv.x) > edge || abs(uv.y) > edge) return 1.0;
  float bias = (0.0002 + 0.0004 * warp) * (1.0 + (1.0 - vLight.a)) * SHADOW_BIAS;
  vec3 c = vec3(uv, vShadow.z * 0.33333) * 0.5 + 0.5;   // depth squeezed by the shadow vertex shader
  c.z -= bias;
  float s;
  #if SHADOW_QUALITY >= 2
  float o = 1.0 / float(shadowMapResolution);
  s = (shadow2D(shadow, c + vec3( o * 0.5,  o * 1.5, 0.0)).x + shadow2D(shadow, c + vec3(-o * 1.5,  o * 0.5, 0.0)).x +
       shadow2D(shadow, c + vec3(-o * 0.5, -o * 1.5, 0.0)).x + shadow2D(shadow, c + vec3( o * 1.5, -o * 0.5, 0.0)).x) * 0.25;
  #else
  s = shadow2D(shadow, c).x;
  #endif
  return mix(1.0, s, vShadow.w);
#else
  return 1.0;
#endif
}

// albedo is linear; ao multiplies only the ambient part
vec3 shadeLit(vec3 albedo, float ao) {
  vec3 amb = lightmapColor(vTex.zw) * vHemi * ao;
  float ndl = celBands(vLight.a, float(CEL_STEPS));
  vec3 direct = vec3(0.0);
  float sh = 1.0;
  bool sunny = dot(vLight.rgb, vec3(1.0)) > 0.0005;
  if (ndl > 0.0 && sunny) {
    sh = shadowLookup();
    direct = vLight.rgb * (ndl * sh);
  }
  // darker shadows: while a light is shining, parts it doesn't reach lose some of their ambient too
  float inShade = (ndl > 0.0) ? (1.0 - sh) : 1.0;
  float dayGate = clamp(luma(vLight.rgb) * 0.6, 0.0, 1.0);
  amb *= 1.0 - SHADOW_DARKNESS * inShade * dayGate * vShadow.w;
  return albedo * (amb + direct);
}
