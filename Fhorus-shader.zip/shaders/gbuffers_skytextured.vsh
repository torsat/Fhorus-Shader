#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform vec3 sunPosition;

varying vec2 uv;
varying vec4 vColor;
varying float vIsSun;
uniform mat4 gbufferModelViewInverse;
varying float vElev;

void main() {
  uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
  vColor = gl_Color;
  vec3 vp = (gl_ModelViewMatrix * gl_Vertex).xyz;
  vElev = normalize(mat3(gbufferModelViewInverse) * vp).y;
  vIsSun = dot(normalize(vp), normalize(sunPosition)) > 0.0 ? 1.0 : 0.0;
  gl_Position = ftransform();
}
