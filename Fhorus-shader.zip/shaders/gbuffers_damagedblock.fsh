#version 120
uniform sampler2D texture;
varying vec2 uv;
varying vec4 vColor;

/* DRAWBUFFERS:1 */
void main() {
  gl_FragData[0] = texture2D(texture, uv) * vColor;
}
