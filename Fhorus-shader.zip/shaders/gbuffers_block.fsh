#version 1
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lit_fsh.glsl"

uniform sampler2D texture;
varying vec4 vColor;

/* DRAWBUFFERS:1 */
void main() {
  vec4 tex = texture2D(texture, vTex.xy) * vColor;
  if (tex.a < 0.1) discard;
  gl_FragData[0] = vec4(shadeLit(toLinear(tex.rgb), 1.0), tex.a);
}
