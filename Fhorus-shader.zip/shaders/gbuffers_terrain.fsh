#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lit_fsh.glsl"

uniform sampler2D texture;
varying vec4 vColor;
varying float vGlow;

// extra strength for light sources (torches, glowstone, lanterns...) on top of GLOW_STRENGTH
const float LIGHT_BOOST = 3.0;

/* DRAWBUFFERS:1 */
void main() {
  vec4 tex = texture2D(texture, vTex.xy);
  if (tex.a < 0.1) discard;
  vec3 albedo = toLinear(tex.rgb * vColor.rgb);
  vec3 col = shadeLit(albedo, vColor.a);

  // only the four glow kinds (1..4) are accepted; anything else can never brighten a block
  if (vGlow > 0.5 && vGlow < 4.5) {
    float m;
    if      (vGlow < 1.5) m = smoothstep(0.10, 0.35, tex.r - max(tex.g, tex.b));
    else if (vGlow < 2.5) m = smoothstep(0.10, 0.35, tex.g - max(tex.r, tex.b));
    else if (vGlow < 3.5) m = smoothstep(0.03, 0.15, min(tex.r, tex.b) - tex.g);
    else                  m = smoothstep(0.25, 0.55, max(tex.r, max(tex.g, tex.b)));   // light sources: only the bright texels glow
    float boost = vGlow > 3.5 ? LIGHT_BOOST : 1.0;
    col += albedo * clamp(m, 0.0, 1.0) * GLOW_STRENGTH * boost;
  }
  gl_FragData[0] = vec4(col, tex.a);
}
