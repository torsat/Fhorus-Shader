#version 120
#define DIM_NETHER
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform vec3 sunPosition;
uniform mat4 gbufferModelViewInverse;
uniform float rainStrength;
uniform ivec2 eyeBrightnessSmooth;
uniform int isEyeInWater;

varying vec2 texcoord;
varying vec3 vSunW;
varying float vExposure;
varying float vFog;       // fog density
varying float vEye;       // how much sky light reaches the eye, 0..1
varying vec3 vWaterFog;

void main() {
  gl_Position = ftransform();
  texcoord = gl_MultiTexCoord0.xy;

  vSunW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
  float sunH = vSunW.y;
  float lum = smoothstep(-0.20, 0.14, sunH);
  float dusk = exp(-(sunH / 0.25) * (sunH / 0.25));

#if defined DIM_OVERWORLD
  vExposure = mix(NIGHT_EXPOSURE, 1.0, lum) * EXPOSURE;
  vFog = (0.0020 + 0.0022 * dusk + 0.008 * rainStrength) * FOG_DENSITY;
#elif defined DIM_NETHER
  vExposure = 0.8 * EXPOSURE;
  vFog = 0.05 * FOG_DENSITY;
#else
  vExposure = 1.6 * EXPOSURE;
  vFog = 0.1 * FOG_DENSITY;
#endif
  vEye = eyeBrightnessSmooth.y / 240.0;
  vWaterFog = vec3(0.03, 0.20, 0.28) * (0.12 + 0.88 * lum) * (0.25 + 0.75 * vEye);
}
