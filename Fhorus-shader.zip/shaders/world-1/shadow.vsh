#version 120
void main() { gl_Position = vec4(10.0); }
