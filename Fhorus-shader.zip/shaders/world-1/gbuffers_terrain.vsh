#version 120
#define DIM_NETHER
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lit_vsh.glsl"

attribute vec4 mc_Entity;
attribute vec2 mc_midTexCoord;
uniform float frameTimeCounter;
uniform vec3 cameraPosition;
varying vec4 vColor;

void main() {
  todSetup();
  vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;

  // block.properties: 10001 = leaves, 10002 = plants
  float id = mc_Entity.x;
  float isLeaf  = (id > 10000.5 && id < 10001.5) ? 1.0 : 0.0;
  float isPlant = (id > 10001.5 && id < 10002.5) ? 1.0 : 0.0;
  float foliage = isLeaf + isPlant;

#if WAVING == 1
  if (foliage > 0.5) {
    vec3 wp = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz + cameraPosition;
    float top = isLeaf + isPlant * (gl_MultiTexCoord0.t < mc_midTexCoord.t ? 1.0 : 0.0);
    float t = frameTimeCounter;
    float ph = wp.x * 0.7 + wp.z * 0.55 + wp.y * 0.3;
    vec2 sway = vec2(sin(t * 1.7 + ph), cos(t * 1.3 + ph * 1.3 + 1.7));
    float amp = (isLeaf * 0.035 + isPlant * 0.07) * top * WAVE_AMOUNT * (1.0 + rainStrength);
    viewPos += mat3(gbufferModelView) * vec3(sway.x, 0.0, sway.y) * amp;
  }
#endif

  litSetup(viewPos, normalize(gl_NormalMatrix * gl_Normal), gl_MultiTexCoord1.xy, foliage);
  vTex.xy = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  vColor = vec4(gl_Color.rgb, mix(1.0, gl_Color.a, AO_STRENGTH));
  gl_Position = foliage > 0.5 ? gl_ProjectionMatrix * vec4(viewPos, 1.0) : ftransform();   // only swaying foliage needs a custom position
}
