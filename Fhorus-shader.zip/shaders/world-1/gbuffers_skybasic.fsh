#version 120
#define DIM_NETHER
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"

uniform sampler2D gaux1;
uniform float viewWidth;
uniform float viewHeight;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 fogColor;
uniform float rainStrength;

varying vec3 vSunW;
varying float vStar;

/* DRAWBUFFERS:1 */
void main() {
  vec3 col;
#if defined DIM_OVERWORLD
  vec2 res = vec2(viewWidth, viewHeight);
  vec4 p = gbufferProjectionInverse * vec4(gl_FragCoord.xy / res * 2.0 - 1.0, 1.0, 1.0);
  vec3 dir = normalize(mat3(gbufferModelViewInverse) * (p.xyz / p.w));
  col = sampleSky(gaux1, dir, vSunW, 1.0 / res);

  // Stars: fade them by how dark the sky really is at that pixel, so they follow the
  // sunset/sunrise colours exactly (they only show once the sky has dimmed).
  if (vStar > 0.5) {
    float a = (1.0 - smoothstep(0.015, 0.090, luma(col))) * (1.0 - rainStrength);
    if (a < 0.01) discard;
    gl_FragData[0] = vec4(mix(col, vec3(1.0, 0.95, 0.9) * 1.5, a), a);
    return;
  }
#elif defined DIM_NETHER
  col = toLinear(fogColor) * 0.5;
#else
  col = vec3(0.020, 0.012, 0.040);
#endif
  gl_FragData[0] = vec4(col, 1.0);
}
