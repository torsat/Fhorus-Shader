#version 120
#define DIM_NETHER
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform vec3 sunPosition;
uniform mat4 gbufferModelViewInverse;
uniform float rainStrength;

varying vec3 vSunW;
varying float vStar;    // 1 on star quads
varying float vNight;   // 0 day .. 1 night

void main() {
  gl_Position = ftransform();
  vSunW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
  vNight = (1.0 - smoothstep(-0.25, 0.0, vSunW.y)) * (1.0 - rainStrength);
  // stars are drawn grey, the sky dome never is exactly grey
  vStar = float(gl_Color.r == gl_Color.g && gl_Color.g == gl_Color.b && gl_Color.r > 0.0);
}
