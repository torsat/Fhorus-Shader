#version 330 compatibility
#define DIM_NETHER
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lit_vsh.glsl"

// Crumb - Distant Horizons terrain (LODs). Same lighting as normal terrain, but the
// blocks have no texture: the colour comes straight from the vertex colour.
varying vec4 vColor;

void main() {
  todSetup();
  vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;

  // light coordinates arrive in 0..1, 0..15 or 0..240 depending on version: bring them to 0..240
  vec2 lm = gl_MultiTexCoord2.xy;
  float mx = max(lm.x, lm.y);
  lm = mx > 15.5 ? lm : (mx > 1.001 ? lm * 16.0 : lm * 240.0);

  litSetup(viewPos, normalize(gl_NormalMatrix * gl_Normal), lm, 0.0);
  vTex.xy = vec2(0.0);
  vColor = vec4(gl_Color.rgb, 1.0);
  gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);
}
