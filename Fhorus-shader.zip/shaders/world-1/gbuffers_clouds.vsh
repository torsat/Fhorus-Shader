#version 120
#define DIM_NETHER
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/tod.glsl"

varying vec2 uv;
varying float vShade;
varying vec3 vSun;

void main() {
  todSetup();
  uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  float ny = normalize(mat3(gbufferModelViewInverse) * (gl_NormalMatrix * gl_Normal)).y;
  vShade = 0.75 + 0.25 * ny;                      // top bright, underside dim
  vSun = gLightCol * 0.5 * vShade;
  gl_Position = ftransform();
}
