#version 120
#define DIM_NETHER
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D texture;
varying vec2 uv;
varying vec4 vColor;
varying float vIsSun;

/* DRAWBUFFERS:1 */
void main() {
  vec4 t = texture2D(texture, uv) * vColor;
#if defined DIM_OVERWORLD
  // the sun and moon sprites are skipped on purpose: their square quads showed up as boxes.
  // The sky table draws a soft glare spot in their place (see lib/sky.glsl).
  discard;
#else
  gl_FragData[0] = vec4(toLinear(t.rgb) * 0.45, vColor.a);   // End sky box
#endif
}
