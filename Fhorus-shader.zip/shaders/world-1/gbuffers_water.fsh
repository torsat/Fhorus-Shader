#version 120
#define DIM_NETHER
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"
#include "/lib/lit_fsh.glsl"

uniform sampler2D texture;
uniform float frameTimeCounter;
uniform vec3 cameraPosition;
uniform int isEyeInWater;

varying vec4 vColor;
varying vec3 vRel;
varying vec3 vNormalW;
varying vec3 vSunW;
varying vec3 vLightW;

/* DRAWBUFFERS:1 */
void main() {
  vec4 tex = texture2D(texture, vTex.xy);
  // vanilla water is a bluish texture tinted by biome colour; flatten it a little
  vec3 albedo = toLinear(vColor.rgb * mix(vec3(luma(tex.rgb)), tex.rgb, 0.4));
  vec3 body = shadeLit(albedo, 1.0);
  float alpha = WATER_ALPHA;

#if defined DIM_OVERWORLD
  if (WATER_REFLECT > 0.0 && isEyeInWater == 0) {
    vec3 V = normalize(vRel);
    vec3 n = normalize(vNormalW);
    vec3 wp = vRel + cameraPosition;
    float t = frameTimeCounter;
    vec2 w = vec2(sin(wp.x * 1.9 + t * 1.4) + sin(wp.z * 2.3 - t * 1.1 + wp.x * 0.7),
                  sin(wp.z * 1.7 + t * 1.2) + sin(wp.x * 2.1 + t * 0.9 - wp.z * 0.6));
    n.xz += w * 0.025 * step(0.5, n.y);
    n = normalize(n);

    vec3 R = reflect(V, n);
    R.y = abs(R.y);
    float fres = (0.04 + 0.96 * pow(1.0 - clamp(dot(n, -V), 0.0, 1.0), 5.0)) * WATER_REFLECT;
    fres = clamp(fres, 0.0, 1.0);

    vec3 refl = sampleSky(gaux1, normalize(R), vSunW, 1.0 / vec2(viewWidth, viewHeight));
    refl *= mix(0.12, 1.0, smoothstep(0.3, 0.9, vTex.w));          // no sky in caves
    float glint = pow(max(dot(R, vLightW), 0.0), 700.0);
    vec3 sun = vLight.rgb * glint * 30.0;

    body = mix(body, refl, fres) + sun;
    alpha = clamp(mix(alpha, 1.0, fres) + luma(sun), 0.0, 1.0);
  }
#endif
  gl_FragData[0] = vec4(body, alpha);
}
