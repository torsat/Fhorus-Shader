#version 120
#define DIM_NETHER
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"

/*
const int colortex1Format = R11F_G11F_B10F;
const int colortex4Format = RGBA16F;
*/
const bool colortex4Clear = false;

uniform sampler2D colortex1;
uniform sampler2D depthtex0;
uniform sampler2D gaux1;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform float viewWidth;
uniform float viewHeight;
uniform float far;
uniform int isEyeInWater;
uniform vec3 fogColor;

#ifdef DISTANT_HORIZONS
uniform sampler2D dhDepthTex0;        // Distant Horizons terrain depth
uniform mat4 dhProjectionInverse;
uniform int dhRenderDistance;         // LOD render distance in blocks
#endif

varying vec2 texcoord;
varying vec3 vSunW;
varying float vExposure;
varying float vFog;
varying float vEye;
varying vec3 vWaterFog;

vec3 tonemap(vec3 x) {
#if TONEMAP == 0
  vec3 c = (x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14);   // ACES-style filmic
#elif TONEMAP == 1
  vec3 c = 1.0 - exp(-x * 1.1);                                       // soft exposure curve
#else
  vec3 c = x / (x + 0.55);                                             // plain Reinhard-ish
#endif
  return clamp(c, 0.0, 1.0);
}

/* DRAWBUFFERS:0 */
void main() {
  vec2 res = vec2(viewWidth, viewHeight);
  vec2 uv = texcoord;
#if PIXEL_SIZE > 1
  float ps = float(PIXEL_SIZE);
  uv = (floor(gl_FragCoord.xy / ps) * ps + 0.5 * ps) / res;
#endif

  vec3 col = texture2D(colortex1, uv).rgb;
  float z = texture2D(depthtex0, uv).x;

  // ---- fog ----
  float edge = far;                      // distance where the world really ends
  bool hit = z < 1.0;
  vec4 vp = gbufferProjectionInverse * vec4(vec3(uv, z) * 2.0 - 1.0, 1.0);
#ifdef DISTANT_HORIZONS
  edge = max(far, float(dhRenderDistance));     // with LODs the world ends at the LOD distance, not the vanilla one
  if (z >= 1.0) {
    float dz = texture2D(dhDepthTex0, uv).x;
    if (dz < 1.0) {
      hit = true;
      vp = dhProjectionInverse * vec4(vec3(uv, dz) * 2.0 - 1.0, 1.0);
    }
  }
#endif
  vp.xyz /= vp.w;
  float dist = length(vp.xyz);

  if (isEyeInWater == 1) {
    col = mix(vWaterFog, col, exp2(-dist * 0.085));
  } else if (hit) {
    vec3 dirW = mat3(gbufferModelViewInverse) * (vp.xyz / dist);
    vec3 fc;
#if defined DIM_OVERWORLD
    vec3 horiz = normalize(vec3(dirW.x, 0.0, dirW.z) + 1e-5);
    fc = sampleSky(gaux1, horiz, vSunW, 1.0 / res) * (0.05 + 0.95 * vEye);
#elif defined DIM_NETHER
    fc = toLinear(fogColor) * 0.5;
#else
    fc = vec3(0.020, 0.012, 0.040);
#endif
    float f = 1.0 - exp2(-dist * vFog);
    // the edge fade follows FOG_DENSITY too: low = a thin fade right at the edge, high = fog starts much closer
    float fogStart = mix(0.90, 0.62, clamp(FOG_DENSITY, 0.0, 1.0)) - 0.12 * clamp(FOG_DENSITY - 1.0, 0.0, 2.0);
    f = max(f, smoothstep(edge * fogStart, edge * 0.97, dist));   // hide the chunk edge
    col = mix(col, fc, f);
  }

  // ---- grade ----
  col *= vExposure;


  col = tonemap(col);
  col = mix(col, col * col * (3.0 - 2.0 * col), CONTRAST);
  col = mix(vec3(luma(col)), col, SATURATION);
  vec2 q = texcoord - 0.5;
  col *= 1.0 - VIGNETTE * smoothstep(0.25, 0.85, length(q) * 1.4);
  col = pow(col, vec3(1.0 / 2.2));
  col += (ign(gl_FragCoord.xy) - 0.5) / 255.0;

  gl_FragData[0] = vec4(col, 1.0);
}
