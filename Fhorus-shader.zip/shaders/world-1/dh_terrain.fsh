#version 330 compatibility
#define DIM_NETHER
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lit_fsh.glsl"

varying vec4 vColor;

/* DRAWBUFFERS:1 */
void main() {
  vec3 albedo = toLinear(vColor.rgb);
  gl_FragData[0] = vec4(shadeLit(albedo, 1.0), 1.0);
}
