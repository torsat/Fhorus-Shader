#version 120
#define DIM_NETHER
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform vec3 sunPosition;

varying vec2 uv;
varying vec4 vColor;
varying float vIsSun;

void main() {
  uv = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
  vColor = gl_Color;
  vec3 vp = (gl_ModelViewMatrix * gl_Vertex).xyz;
  vIsSun = dot(normalize(vp), normalize(sunPosition)) > 0.0 ? 1.0 : 0.0;
  gl_Position = ftransform();
}
