#version 1
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"
#include "/lib/tod.glsl"

uniform float viewWidth;
uniform float viewHeight;

varying float vSunH;
varying vec3 vAmbient;   // sky ambient colour for this frame

void main() {
  todSetup();
  vSunH = gSunH;
  vAmbient = skyAmbient(gSunH, rainStrength) + gLightCol * 0.06;   // a little bounce light

  // squeeze the full-screen quad into the 288x64 corner that holds the tables
  vec2 q = ftransform().xy * 0.5 + 0.5;
  vec2 px = vec2(288.0, 64.0) / vec2(viewWidth, viewHeight);
  gl_Position = vec4(q * px * 2.0 - 1.0, 0.0, 1.0);
}
