#version 330 compatibility
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lit_vsh.glsl"

// Crumb - Distant Horizons water
varying vec4 vColor;
varying vec3 vRel;      // camera-relative world position
varying vec3 vNormalW;  // world normal
varying vec3 vSunW;     // sun direction, world
varying vec3 vLightW;   // active light direction, world

void main() {
  todSetup();
  vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
  vec3 nView = normalize(gl_NormalMatrix * gl_Normal);

  vec2 lm = gl_MultiTexCoord2.xy;
  float mx = max(lm.x, lm.y);
  lm = mx > 15.5 ? lm : (mx > 1.001 ? lm * 16.0 : lm * 240.0);

  litSetup(viewPos, nView, lm, 0.0);
  vTex.xy = vec2(0.0);
  vColor = gl_Color;
  vRel = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
  vNormalW = mat3(gbufferModelViewInverse) * nView;
  vSunW = gSunDirW;
  vLightW = mat3(gbufferModelViewInverse) * gLightDirV;
  gl_Position = gl_ProjectionMatrix * vec4(viewPos, 1.0);
}
