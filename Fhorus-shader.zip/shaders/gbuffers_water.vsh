#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/lit_vsh.glsl"

attribute vec4 mc_Entity;
varying float vIsWater;
varying vec4 vColor;
varying vec3 vRel;      // camera-relative world position
varying vec3 vNormalW;  // world normal
varying vec3 vSunW;     // sun direction, world
varying vec3 vLightW;   // active light direction, world

void main() {
  todSetup();
  vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
  vec3 nView = normalize(gl_NormalMatrix * gl_Normal);
  litSetup(viewPos, nView, gl_MultiTexCoord1.xy, 0.0);
  vTex.xy = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
  vColor = gl_Color;
  vIsWater = step(abs(mc_Entity.x - 8.0), 0.5);
  vRel = mat3(gbufferModelViewInverse) * viewPos + gbufferModelViewInverse[3].xyz;
  vNormalW = mat3(gbufferModelViewInverse) * nView;
  vSunW = gSunDirW;
  vLightW = mat3(gbufferModelViewInverse) * gLightDirV;
  gl_Position = ftransform();   // exactly the vanilla position, so the enchant glint overlay passes the depth test
}
