#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

attribute vec4 mc_Entity;
varying vec2 uv;

void main() {
  vec4 p = ftransform();
  p.xy /= shadowWarp(p.xy);
  p.z *= 0.33333;                       // must match the depth squeeze in lib/lit_fsh.glsl
  if (mc_Entity.x == 8.0) p = vec4(10.0); // water casts no shadow
  gl_Position = p;
  uv = gl_MultiTexCoord0.xy;
}
