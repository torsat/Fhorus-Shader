#version 120
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D texture;
uniform sampler2D gaux1;
uniform float viewWidth;
uniform float viewHeight;

varying vec2 uv;
varying vec4 vColor;
varying vec3 vSun;

/* DRAWBUFFERS:1 */
void main() {
  vec4 t = texture2D(texture, uv);
  float a = t.a * 0.45 * vColor.a;
  if (a < 0.01) discard;
  vec3 amb = texture2D(gaux1, vec2(16.5, 0.5) / vec2(viewWidth, viewHeight)).rgb;
  gl_FragData[0] = vec4((amb * 1.5 + vSun) * t.rgb, a);
}
