#version 1
#include "/lib/settings.glsl"
#include "/lib/common.glsl"

uniform sampler2D texture;
varying vec2 uv;
varying vec4 vColor;

/* DRAWBUFFERS:1 */
void main() {
  vec4 t = texture2D(texture, uv) * vColor;
  gl_FragData[0] = vec4(toLinear(t.rgb) * 1.2, t.a);
}
