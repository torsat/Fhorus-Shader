#version 1
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"

/*
const int colortex1Format = R11F_G11F_B10F;
const int colortex4Format = RGBA16F;
*/
// the tables are rebuilt every frame, so the buffer never needs clearing
const bool colortex4Clear = false;

uniform float rainStrength;
varying float vSunH;
varying vec3 vAmbient;

/* DRAWBUFFERS:4 */
void main() {
  vec2 p = floor(gl_FragCoord.xy);
  vec3 outc = vec3(0.0);

  if (p.x < 16.0 && p.y < 16.0) {
    // lightmap: x = block light, y = sky light
    float s = p.y / 15.0;
    float b = p.x / 15.0;
    float skyL = s * s * (0.6 * s + 0.4);
    float torchL = b * b * b * b * 1.6 + b * b * 0.35 + b * 0.05;
    vec3 torch = vec3(TORCH_R, TORCH_G, TORCH_B) * TORCH_AMOUNT;
    outc = vAmbient * skyL + torch * torchL + vec3(0.75, 1.0, 1.25) * 0.004 * MIN_LIGHT;
  } else if (p.x >= 16.0 && p.x < 17.0 && p.y < 1.0) {
    outc = vAmbient;
  } else if (p.x >= 32.0 && p.x < 288.0 && p.y < 64.0) {
    float d = ((p.x - 32.0 + 0.5) / 256.0 - 0.5) * 2.0;
    float v = (p.y + 0.5) / 64.0;
    float a = 1.0 - abs(d);
    float cosY = sign(d) * (1.0 - a * a * a * a);
    outc = skyModel(cosY, v * v, vSunH, rainStrength);
  }
  gl_FragData[0] = vec4(outc, 1.0);
}
