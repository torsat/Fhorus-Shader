#version 330 compatibility
#include "/lib/settings.glsl"
#include "/lib/common.glsl"
#include "/lib/sky.glsl"
#include "/lib/lit_fsh.glsl"

uniform int isEyeInWater;

varying vec4 vColor;
varying vec3 vRel;
varying vec3 vNormalW;
varying vec3 vSunW;
varying vec3 vLightW;

/* DRAWBUFFERS:1 */
void main() {
  vec3 albedo = toLinear(vColor.rgb);
  vec3 body = shadeLit(albedo, 1.0);
  float alpha = WATER_ALPHA;

#if defined DIM_OVERWORLD
  if (WATER_REFLECT > 0.0 && isEyeInWater == 0) {
    vec3 V = normalize(vRel);
    vec3 n = normalize(vNormalW);
    vec3 R = reflect(V, n);
    R.y = abs(R.y);
    float fres = (0.04 + 0.96 * pow(1.0 - clamp(dot(n, -V), 0.0, 1.0), 5.0)) * WATER_REFLECT;
    fres = clamp(fres, 0.0, 1.0);
    vec3 refl = sampleSky(gaux1, normalize(R), vSunW, 1.0 / vec2(viewWidth, viewHeight));
    refl *= mix(0.12, 1.0, smoothstep(0.3, 0.9, vTex.w));          // no sky in caves
    float glint = pow(max(dot(R, vLightW), 0.0), SUN_GLINT_SHARP);   // bigger number = smaller, sharper glint
    vec3 sun = min(vLight.rgb * glint * SUN_GLINT_BRIGHT, vec3(1.5));   // capped so it can never blow out to a white patch
    body = mix(body, refl, fres) + sun;
    alpha = clamp(mix(alpha, 1.0, fres) + luma(sun), 0.0, 1.0);
  }
#endif
  gl_FragData[0] = vec4(body, alpha);
}
